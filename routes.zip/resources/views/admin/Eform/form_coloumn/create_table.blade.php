
                                          <div class="form-group">
                                              <label for="name">نام فیلد</label>
                                              <input type="text" class="form-control" id="name" autocomplete="off"
                                                  placeholder=" نام فیلد  " name="name" value="{{ old('name') }}">
                                          </div>

                                          <div class="form-group">
                                              <label for="place">متن plac </label>
                                              <input type="text" class="form-control" id="link" autocomplete="off"
                                                  placeholder=" متن plac   " name="place" value="{{ old('place') }}">
                                          </div>





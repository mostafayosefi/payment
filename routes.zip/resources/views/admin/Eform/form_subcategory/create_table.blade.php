
                                          <div class="form-group">
                                              <label for="name">نام زیرگروه</label>
                                              <input type="text" class="form-control" id="name" autocomplete="off"
                                                  placeholder=" نام زیرگروه  " name="name" value="{{ old('name') }}">
                                          </div>

                                          <div class="form-group">
                                              <label for="link">لینک </label>
                                              <input type="text" class="form-control" id="link" autocomplete="off"
                                                  placeholder=" لینک   " name="link" value="{{ old('link') }}">
                                          </div>



 
